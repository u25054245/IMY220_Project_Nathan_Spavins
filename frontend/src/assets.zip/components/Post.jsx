import { Link, useParams } from "react-router-dom";
import EditPost from "../components/EditPost";
import Comments from "./Comments"

import { useState, useEffect } from "react";

function Post() {
    const { id } = useParams();
    
    const [post, setPost] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    
    async function loadPost(url) {
        setLoading(true);
        setError("");
        
        try {
            const response = await fetch(url);

            if(!response.ok) {
                throw new Error("Error in fetching post.");
            }

            const data = await response.json();
            setPost(data);
        } catch(error) {
            setError(error.message);
            console.error(error.message);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadPost(`http://localhost:3000/api/exposures/${id}`)
    }, [id]);

    return (
        <div className="post">
            { loading && <p>Loading...</p> }
            { error && !loading && <p>{ error }</p>}
            
            {!loading && !error && 
                <div>
                    <img src={post.image}/>
            
                    <div className="post-content">
                        <h2>{post.title}</h2>
                        <p>{post.location}</p>
                        <p>{post.views}</p>
                        <p>{post.author}</p>
                    </div>

                    <div className="post-description">
                        <p>{post.description}</p>
                        <Link to={'/Home'}><button type="submit">Back</button></Link>
                    </div>

                    <Comments key={post.id} comments={post.comments}/>

                    <EditPost />
                </div>
            }
        </div>
    );
}

export default Post;